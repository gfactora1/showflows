'use client'

import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabaseClient'

type Project = {
  id: string
  name: string
  color: string
  created_at: string
}

type Member = {
  id: string
  project_id: string
  member_email: string
  role: 'owner' | 'editor' | 'member' | 'readonly'
  is_managed: boolean
  created_at: string
}

export default function ProjectMembers({ project }: { project: Project }) {
  const [members, setMembers] = useState<Member[]>([])
  const [email, setEmail] = useState('')
  const [role, setRole] = useState<Member['role']>('member')
  const [isManaged, setIsManaged] = useState(false)
  const [loading, setLoading] = useState(false)
  const [msg, setMsg] = useState('')

  const loadMembers = async () => {
    setMsg('')
    const { data, error } = await supabase
      .from('project_members')
      .select('id,project_id,member_email,role,is_managed,created_at')
      .eq('project_id', project.id)
      .order('created_at', { ascending: true })

    if (error) {
      setMsg(`Error loading members: ${error.message}`)
      return
    }

    setMembers((data ?? []) as Member[])
  }

  useEffect(() => {
    loadMembers()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [project.id])

  const addMember = async () => {
    setMsg('')
    const trimmed = email.trim().toLowerCase()
    if (!trimmed) return

    setLoading(true)
    const { error } = await supabase.from('project_members').insert({
      project_id: project.id,
      member_email: trimmed,
      role,
      is_managed: isManaged,
    })
    setLoading(false)

    if (error) {
      setMsg(`Error adding member: ${error.message}`)
      return
    }

    setEmail('')
    setRole('member')
    setIsManaged(false)
    await loadMembers()
  }

  const updateMember = async (id: string, patch: Partial<Member>) => {
    setMsg('')
    const { error } = await supabase
      .from('project_members')
      .update(patch)
      .eq('id', id)

    if (error) {
      setMsg(`Error updating member: ${error.message}`)
      return
    }

    await loadMembers()
  }

  const removeMember = async (id: string) => {
    setMsg('')
    const ok = confirm('Remove this member?')
    if (!ok) return

    const { error } = await supabase.from('project_members').delete().eq('id', id)
    if (error) {
      setMsg(`Error removing member: ${error.message}`)
      return
    }

    await loadMembers()
  }

  return (
    <section>
      <h3 style={{ marginTop: 0 }}>Members — {project.name}</h3>

      <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        <input
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="member@email.com"
          style={{ padding: 8, width: 260 }}
        />

        <select
          value={role}
          onChange={(e) => setRole(e.target.value as Member['role'])}
          style={{ padding: 8 }}
        >
          <option value="editor">editor</option>
          <option value="member">member</option>
          <option value="readonly">readonly</option>
        </select>

        <label style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <input
            type="checkbox"
            checked={isManaged}
            onChange={(e) => setIsManaged(e.target.checked)}
          />
          Managed member
        </label>

        <button onClick={addMember} disabled={loading}>
          {loading ? 'Adding...' : 'Add'}
        </button>
      </div>

      {msg && <p style={{ marginTop: 12 }}>{msg}</p>}

      <table style={{ marginTop: 16, width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th style={{ textAlign: 'left', borderBottom: '1px solid #ddd', padding: 8 }}>
              Email
            </th>
            <th style={{ textAlign: 'left', borderBottom: '1px solid #ddd', padding: 8 }}>
              Role
            </th>
            <th style={{ textAlign: 'left', borderBottom: '1px solid #ddd', padding: 8 }}>
              Managed
            </th>
            <th style={{ borderBottom: '1px solid #ddd', padding: 8 }} />
          </tr>
        </thead>
        <tbody>
          {members.map((m) => (
            <tr key={m.id}>
              <td style={{ padding: 8, borderBottom: '1px solid #f0f0f0' }}>
                {m.member_email}
              </td>

              <td style={{ padding: 8, borderBottom: '1px solid #f0f0f0' }}>
                {m.role === 'owner' ? (
                  <span>owner</span>
                ) : (
                  <select
                    value={m.role}
                    onChange={(e) =>
                      updateMember(m.id, { role: e.target.value as Member['role'] })
                    }
                    style={{ padding: 6 }}
                  >
                    <option value="editor">editor</option>
                    <option value="member">member</option>
                    <option value="readonly">readonly</option>
                  </select>
                )}
              </td>

              <td style={{ padding: 8, borderBottom: '1px solid #f0f0f0' }}>
                <input
                  type="checkbox"
                  checked={m.is_managed}
                  onChange={(e) => updateMember(m.id, { is_managed: e.target.checked })}
                  disabled={m.role === 'owner'}
                />
              </td>

              <td style={{ padding: 8, borderBottom: '1px solid #f0f0f0', textAlign: 'right' }}>
                {m.role !== 'owner' && (
                  <button onClick={() => removeMember(m.id)}>Remove</button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {members.length === 0 && (
        <p style={{ marginTop: 12, opacity: 0.8 }}>
          No members yet — add one above.
        </p>
      )}
    </section>
  )
}